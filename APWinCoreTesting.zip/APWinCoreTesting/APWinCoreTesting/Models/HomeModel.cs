﻿namespace APWinCoreTesting.Models
{
    public class HomeModel
    {
        public string MerchantId { get; set; }
        public string PaymentKey { get; set; }
        public string StoreName { get; set; }
    }
}
