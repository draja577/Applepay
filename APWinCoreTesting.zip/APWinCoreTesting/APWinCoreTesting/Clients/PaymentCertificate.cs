//using System;
//using System.Buffers.Text;
//using System.IO;
//using System.Numerics;
//using System.Security.Cryptography;
//using System.Security.Cryptography.X509Certificates;
//using System.Text;
//using APWinCoreTesting.Models;
//using Microsoft.Extensions.Options;
//using Org.BouncyCastle.Asn1;
//using Org.BouncyCastle.Asn1.Pkcs;
//using Org.BouncyCastle.Asn1.Sec;
//using Org.BouncyCastle.Asn1.X509;
//using Org.BouncyCastle.Asn1.X9;
//using Org.BouncyCastle.Crypto;
//using Org.BouncyCastle.Crypto.Agreement.Kdf;
//using Org.BouncyCastle.Crypto.Digests;
//using Org.BouncyCastle.Crypto.Encodings;
//using Org.BouncyCastle.Crypto.Engines;
//using Org.BouncyCastle.Crypto.Parameters;
//using Org.BouncyCastle.Math;
//using Org.BouncyCastle.OpenSsl;
//using Org.BouncyCastle.Pkcs;
//using Org.BouncyCastle.Security;
//using Org.BouncyCastle.Utilities.Encoders;
//using Base64 = Org.BouncyCastle.Utilities.Encoders.Base64;
//using BigInteger = Org.BouncyCastle.Math.BigInteger;

//namespace APWinCoreTesting.Clients
//{
//    public class PaymentCertificate
//    {
//        private readonly ApplePayOptions _options;
//        private readonly ApplePayRequest applePayRequest;
//        private readonly byte[] symmetricIv;
//        public PaymentCertificate(IOptions<ApplePayOptions> options, IOptions<ApplePayRequest> req)
//        {
//            _options = options.Value;
//            applePayRequest = req.Value;
//            applePayRequest.ApplePayHeader = new ApplePayHeader();
//            symmetricIv = Hex.Decode("00000000000000000000000000000000");
//        }

//        public X509Certificate2 GetCertificate()
//        {
//            // Get the merchant certificate for two-way TLS authentication with the Apple Pay server.
//            if (_options.UseCertificateStore)
//            {
//                return LoadCertificateFromStore();
//            }
//            else
//            {
//                return LoadCertificateFromDisk();
//            }
//        }

//        public string GetPaymentIdentifier()
//        {
//            try
//            {
//                var merchantCertificate = GetCertificate();
//                return GetPaymentIdentifier(merchantCertificate);
//            }
//            catch (InvalidOperationException)
//            {
//                return string.Empty;
//            }
//        }

//        private string GetPaymentIdentifier(X509Certificate2 certificate)
//        {
//            // This OID returns the ASN.1 encoded merchant identifier
//            var extension = certificate.Extensions["1.2.840.113635.100.6.32"];

//            if (extension == null)
//            {
//                return string.Empty;
//            }

//            // Convert the raw ASN.1 data to a string containing the ID
//            return Encoding.ASCII.GetString(extension.RawData).Substring(2);
//        }

//        private X509Certificate2 LoadCertificateFromDisk()
//        {
//            try
//            {
//                return new X509Certificate2(
//                    _options.PaymentCertificateFileName,
//                    _options.PaymentCertificatePassword);
//            }
//            catch (Exception ex)
//            {
//                throw new InvalidOperationException($"Failed to load Apple Pay merchant certificate file from '{_options.MerchantCertificateFileName}'.", ex);
//            }
//        }
//        public byte[] GetPrivateKeyFromP12File()
//        {
//            var identit = GetPaymentIdentifier();
//            X509Certificate2 certificate = new X509Certificate2(_options.PaymentCertificateFileName, _options.PaymentCertificatePassword, X509KeyStorageFlags.Exportable | X509KeyStorageFlags.PersistKeySet);
//            //X509Certificate2 certificate = new X509Certificate2("filename.pfx", "password", X509KeyStorageFlags.Exportable | X509KeyStorageFlags.PersistKeySet);

//            // Now you have your private key in binary form as you wanted
//            // You can use rsa.ExportParameters() or rsa.ExportCspBlob() to get you bytes
//            // depending on format you need them in
//            RSACng rsa = (RSACng)certificate.PrivateKey;

//            // Just for lulz, let's write out the PEM representation of the private key
//            // using Bouncy Castle, so that we are 100% sure that the result is exaclty the same as:
//            // openssl pkcs12 -in filename.pfx -nocerts -out privateKey.pem
//            // openssl.exe rsa -in privateKey.pem -out private.pem

//            // You should of course dispose of / close the streams properly. I'm skipping this part for brevity
//            MemoryStream memoryStream = new MemoryStream();
//            TextWriter streamWriter = new StreamWriter(memoryStream);
//            PemWriter pemWriter = new PemWriter(streamWriter);

//            AsymmetricCipherKeyPair keyPair = DotNetUtilities.GetRsaKeyPair(rsa);
//            pemWriter.WriteObject(keyPair.Private);
//            streamWriter.Flush();

//            // Here is the output with ---BEGIN RSA PRIVATE KEY---
//            // that should be exactly the same as in private.pem
//            return memoryStream.GetBuffer();
//        }

//        public string Decrypt()
//        {
//            applePayRequest.Data = "2sNbpj9MvUJuuyhqKSyeNKBHEAGSd5eMakpQCQW9mq3jN5mnN3sZP+cLcDDVANJFB1hDM9iEOxM6RgFDSmI4zG24t4T4oKAJSplmWyRQa+lK+tkUCmmXAbJxt1dL4PXI0EyiCw6FV7etMLH8ndZJvFQgunskw9SeriB/EmRXwAVHubL2IQVZm1kzBYajVO9gJb4D8wxGuejNri+KtuF9wfzssHqli41/RHMbBDUdakmK3KpN9Usq0t7KN/O9kTXOkv6VBUXXClkRhHjNYteV+sls6pEJEPumf23xtU1ekt0cFYu5+rFpQp2ed8MlK+CIcdmkaM2vBK6OKyheiOcZkLM2IJigLK7LLRkpBKmxpk+5LSy8gcH2ps2cz7y9x60DBYTby5uQpxw49AUny/mIczz9gOF7/bRR3PkkEtjZipyXfJgJS8ehhDJTAUfYo2aIffbjPPhxZZSL62+5FqktUuHaaB84h/YwZzDPvENS9tp6tGC84E2/YP7DcuZvyB7KSWcTv8xiWnoxSRjGOMnQWbFkIWWJdz0JGGw9BKR4aNmZ2sXsLuA2PuutBcU=";
//            applePayRequest.ApplePayHeader.EphemeralPublicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEWwCRpjPGhasAL98stCTpIdGu5pGPI/68rKw2tbuD2IECKIc9i/Bj2UPw3QF7Bd0RebhSfJntmhSj1T/b1RtuGQ==";
//            var data = readPrivateKey(@"C:\Users\lkotaru\Desktop\TEST PROJECT\ApplePay\tradfile.pem");
//            //C:\Users\lkotaru\Desktop\TEST PROJECT\ApplePay
//            //var decryptEngine = new Pkcs1Encoding(new RsaEngine());
//            //decryptEngine.Init(false, data);

//            //var decrypted = Encoding.UTF8.GetString(decryptEngine.ProcessBlock(data, 0, dodata.Length));


//            var privateKey = GetMerchantPrivateKey(data);
//            byte[] ephemeralPublicKey = Base64.Decode(applePayRequest.ApplePayHeader.EphemeralPublicKey);
//            var publickey = GetPublicKeyParameters(ephemeralPublicKey);

//            byte[] sharedSecretBytes = GenerateSharedSecret(privateKey, publickey);
//            byte[] encryptionKeyBytes = RestoreSymmertricKey(sharedSecretBytes);

//            byte[] decryptedBytes = DoDecrypt(Convert.FromBase64String(applePayRequest.Data), encryptionKeyBytes);
//            string decryptedString = System.Text.Encoding.Default.GetString(decryptedBytes);

//            return string.Empty;
//        }

//        static byte[] readPrivateKey(string privateKeyFileName)
//        {
//            //AsymmetricCipherKeyPair keyPair;

//            //using (var reader = File.OpenText(privateKeyFileName)) // file containing RSA PKCS1 private key
//            //    keyPair = (AsymmetricCipherKeyPair)new PemReader(reader).ReadObject();
//            //return keyPair;

//            AsymmetricCipherKeyPair Key;
//            TextReader tr = new StreamReader(privateKeyFileName);
//            PemReader pr = new PemReader(tr);
//            Key = (AsymmetricCipherKeyPair)pr.ReadObject();
//            pr.Reader.Close();
//            tr.Close();
//            //return Key.Private;

//            PrivateKeyInfo privateKeyInfo = PrivateKeyInfoFactory.CreatePrivateKeyInfo(Key.Private);
//            byte[] serializedPrivateBytes = privateKeyInfo.ToAsn1Object().GetDerEncoded();

//            return serializedPrivateBytes;

//        }
//        private static object ReadPem(string fileName)
//        {
//            if (!File.Exists(fileName))
//                throw new FileNotFoundException("The key file does not exist: " + fileName);

//            using (StreamReader file = new StreamReader(fileName))
//            {
//                PemReader pRd = new PemReader(file);

//                object obj = pRd.ReadObject();
//                pRd.Reader.Close();
//                if (obj == null)
//                {
//                    throw new FormatException("The key file " + fileName + " is no valid PEM format");
//                }
//                return obj;
//            }
//        }
//        private X509Certificate2 LoadCertificateFromStore()
//        {
//            // Load the certificate from the current user's certificate store. This
//            // is useful if you do not want to publish the merchant certificate with
//            // your application, but it is also required to be able to use an X.509
//            // certificate with a private key if the user profile is not available,
//            // such as when using IIS hosting in an environment such as Microsoft Azure.
//            using (var store = new X509Store(StoreName.My, StoreLocation.CurrentUser))
//            {
//                store.Open(OpenFlags.ReadOnly);

//                var certificates = store.Certificates.Find(
//                    X509FindType.FindByThumbprint,
//                    _options.MerchantCertificateThumbprint?.Trim(),
//                    validOnly: false);

//                if (certificates.Count < 1)
//                {
//                    throw new InvalidOperationException(
//                        $"Could not find Apple Pay merchant certificate with thumbprint '{_options.MerchantCertificateThumbprint}' from store '{store.Name}' in location '{store.Location}'.");
//                }

//                return certificates[0];
//            }
//        }



//        public ECPublicKeyParameters GetPublicKeyParameters(byte[] ephemeralPublicKeyBytes)
//        {
//            return (ECPublicKeyParameters)PublicKeyFactory.CreateKey(ephemeralPublicKeyBytes);
//        }

//        public static ECPrivateKeyParameters GetMerchantPrivateKey(byte[] privateKeyBite)
//        {
//            Asn1Sequence seq = (Asn1Sequence)Asn1Object.FromByteArray(privateKeyBite);
//            ECPrivateKeyStructure pKey = ECPrivateKeyStructure.GetInstance(seq);
//            AlgorithmIdentifier algId = new AlgorithmIdentifier(X9ObjectIdentifiers.IdECPublicKey, pKey.GetParameters());

//            PrivateKeyInfo privInfo = new PrivateKeyInfo(algId, pKey.ToAsn1Object());

//            return (ECPrivateKeyParameters)PrivateKeyFactory.CreateKey(privateKeyBite);
//        }

//        private byte[] GenerateSharedSecret(ECPrivateKeyParameters privateKey, ECPublicKeyParameters publicKeys)
//        {
//            ECPrivateKeyParameters keyParams = privateKey;
//            IBasicAgreement agree = AgreementUtilities.GetBasicAgreement("ECDH");
//            agree.Init(keyParams);
//            BigInteger sharedSecret = agree.CalculateAgreement(publicKeys);
//            return sharedSecret.ToByteArrayUnsigned();
//        }

//        protected byte[] RestoreSymmertricKey(byte[] sharedSecretBytes)
//        {
//            byte[] merchantIdentifier = GetHashSha256Bytes("merchant.applepaytest.azurewebsites.net");//applePayRequest.MerchantIdentifier);

//            ConcatenationKdfGenerator generator = new ConcatenationKdfGenerator(new Sha256Digest());
//            //byte[] COUNTER = { 0x00, 0x00, 0x00, 0x01 };
//            byte[] algorithmIdBytes = Encoding.UTF8.GetBytes((char)0x0d + "id-aes256-GCM");
//            byte[] partyUInfoBytes = Encoding.UTF8.GetBytes("Apple");
//            byte[] partyVInfoBytes = merchantIdentifier;
//            byte[] otherInfoBytes = Combine(Combine(algorithmIdBytes, partyUInfoBytes), partyVInfoBytes);

//            generator.Init(new KdfParameters(sharedSecretBytes, otherInfoBytes));
//            byte[] encryptionKeyBytes = new byte[32];
//            generator.GenerateBytes(encryptionKeyBytes, 0, encryptionKeyBytes.Length);
//            return encryptionKeyBytes;
//        }

//        private byte[] DoDecrypt(byte[] cipherData, byte[] encryptionKeyBytes)
//        {
//            byte[] output;
//            try
//            {
//                KeyParameter keyparam = ParameterUtilities.CreateKeyParameter("AES", encryptionKeyBytes);
//                ParametersWithIV parameters = new ParametersWithIV(keyparam, symmetricIv);
//                IBufferedCipher cipher = GetCipher();
//                cipher.Init(false, parameters);
//                try
//                {
//                    output = cipher.DoFinal(cipherData);
//                }
//                catch (Exception ex)
//                {
//                    throw new ApplicationException("Invalid Data");
//                }
//            }
//            catch (Exception ex)
//            {
//                throw new ApplicationException("There was an error occured when decrypting message.");
//            }

//            return output;
//        }

//        public IBufferedCipher GetCipher()
//        {
//            return CipherUtilities.GetCipher("AES/GCM/NoPadding");
//        }



//        private static byte[] GetHashSha256Bytes(string text)
//        {
//            byte[] bytes = Encoding.UTF8.GetBytes(text);
//            SHA256Managed hashstring = new SHA256Managed();
//            byte[] hash = hashstring.ComputeHash(bytes);
//            return hash;
//        }

//        protected static byte[] Combine(byte[] first, byte[] second)
//        {
//            byte[] ret = new byte[first.Length + second.Length];
//            Buffer.BlockCopy(first, 0, ret, 0, first.Length);
//            Buffer.BlockCopy(second, 0, ret, first.Length, second.Length);
//            return ret;
//        }
//    }
//}
using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using APWinCoreTesting.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Pkcs;
using Org.BouncyCastle.Asn1.Sec;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Asn1.X9;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Agreement.Kdf;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto.Encodings;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Utilities.Encoders;

namespace APWinCoreTesting.Clients
{
    public class PaymentCertificate
    {
        private readonly ApplePayOptions _options;
        private readonly ApplePayRequest applePayRequest;
        private readonly byte[] symmetricIv;
        private readonly IHostingEnvironment _env;
       
        //public PaymentCertificate(IOptions<ApplePayOptions> options, IOptions<ApplePayRequest> req)
        //{
        //    _options = options.Value;
        //    applePayRequest = req.Value;
        //    applePayRequest.ApplePayHeader = new ApplePayHeader();
        //    symmetricIv = Hex.Decode("00000000000000000000000000000000");
        //}


        //public string Decrypt(string paymentFilePath)
        //{
        //    //applePayRequest.Data = "2sNbpj9MvUJuuyhqKSyeNKBHEAGSd5eMakpQCQW9mq3jN5mnN3sZP+cLcDDVANJFB1hDM9iEOxM6RgFDSmI4zG24t4T4oKAJSplmWyRQa+lK+tkUCmmXAbJxt1dL4PXI0EyiCw6FV7etMLH8ndZJvFQgunskw9SeriB/EmRXwAVHubL2IQVZm1kzBYajVO9gJb4D8wxGuejNri+KtuF9wfzssHqli41/RHMbBDUdakmK3KpN9Usq0t7KN/O9kTXOkv6VBUXXClkRhHjNYteV+sls6pEJEPumf23xtU1ekt0cFYu5+rFpQp2ed8MlK+CIcdmkaM2vBK6OKyheiOcZkLM2IJigLK7LLRkpBKmxpk+5LSy8gcH2ps2cz7y9x60DBYTby5uQpxw49AUny/mIczz9gOF7/bRR3PkkEtjZipyXfJgJS8ehhDJTAUfYo2aIffbjPPhxZZSL62+5FqktUuHaaB84h/YwZzDPvENS9tp6tGC84E2/YP7DcuZvyB7KSWcTv8xiWnoxSRjGOMnQWbFkIWWJdz0JGGw9BKR4aNmZ2sXsLuA2PuutBcU=";
        //    applePayRequest.Data = "lOVDg9czl0UlxQEF+m+yJk8Hfkk7HQFeRqnwUfr/DCSolTITxVaeKluXCN9+116RlhF/io/pnWuR1lqug/YZplusP+yk7G4h6caird31jmsnn6w3GUBIfVWgE604JKQlZY2x7Zk2T5RWhbZBQp4CKg2Y7PhT9yfjt+ifY934BKLz0Z3i4z9l0OHHHgggXxATgJENX0f1nfHpCkmUu3yWgabNP6E0oazlwTaDPN2vkUlL0DS+UbZafAEpRiS4FHo9EZ9emeXQHpmab056Oq5MKlL6mpMXSkX3nMPQQ9LZ6tuDXUu82OxUIwoCHuyqGs8FY3tFoWlUb7lGRoFJiZaF4QYc0mRbFPbp32JPOjCLlgB38dFNABAT35VIMSmGcsDL6+4t9r0ZM+j8dYoN/Q==";
        //    //applePayRequest.ApplePayHeader.EphemeralPublicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEWwCRpjPGhasAL98stCTpIdGu5pGPI/68rKw2tbuD2IECKIc9i/Bj2UPw3QF7Bd0RebhSfJntmhSj1T/b1RtuGQ==";
        //    //var privateKey = readPrivateKey(@"C:\Users\lkotaru\Desktop\TEST PROJECT\ApplePay\tradfile.pem");
        //    applePayRequest.ApplePayHeader.EphemeralPublicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEUAeZrER9/mVRk3qP/G1TR/jSJBW2EjZQiLjYjDRSh9fry511FEui4f5W/6OEykAWyuS5Sop017PTfWDL4R1a5w==";
        //    var privateKey = readPrivateKey(paymentFilePath);
        //    byte[] ephemeralPublicKey = Base64.Decode(applePayRequest.ApplePayHeader.EphemeralPublicKey);
        //    var publickey = GetPublicKeyParameters(ephemeralPublicKey);

        //    byte[] sharedSecretBytes = GenerateSharedSecret(privateKey, publickey);
        //    byte[] encryptionKeyBytes = RestoreSymmertricKey(sharedSecretBytes);

        //    byte[] decryptedBytes = DoDecrypt(Convert.FromBase64String(applePayRequest.Data), encryptionKeyBytes);
        //    string decryptedString = System.Text.Encoding.Default.GetString(decryptedBytes);

        //    return decryptedString;
        //}

        public PaymentCertificate(IOptions<ApplePayRequest> req, IHostingEnvironment env)
        {
            _env = env;
            symmetricIv = Hex.Decode("00000000000000000000000000000000");
        }
        public string Decrypt(ApplePayRequest applePayRequest)
        {
            var webRoot = _env.WebRootPath;
            var privateKey = readPrivateKey(Path.Combine(webRoot, @"Certs\tradfile.pem"));
            byte[] ephemeralPublicKey = Base64.Decode(applePayRequest.Header.EphemeralPublicKey);
            var publicKey = GetPublicKeyParameters(ephemeralPublicKey);

            byte[] sharedSecretBytes = GenerateSharedSecret(privateKey, publicKey);
            byte[] encryptionKeyBytes = RestoreSymmertricKey(sharedSecretBytes);

            byte[] decryptedBytes = DoDecrypt(Convert.FromBase64String(applePayRequest.Data), encryptionKeyBytes);
            string decryptedString = Encoding.Default.GetString(decryptedBytes);

            return decryptedString;
        }
        static ECPrivateKeyParameters readPrivateKey(string privateKeyFileName)
        {
            AsymmetricCipherKeyPair Key;
            TextReader tr = new StreamReader(privateKeyFileName);
            PemReader pr = new PemReader(tr);
            Key = (AsymmetricCipherKeyPair)pr.ReadObject();
            pr.Reader.Close();
            tr.Close();

            PrivateKeyInfo privateKeyInfo = PrivateKeyInfoFactory.CreatePrivateKeyInfo(Key.Private);
            byte[] serializedPrivateBytes = privateKeyInfo.ToAsn1Object().GetDerEncoded();

            return (ECPrivateKeyParameters)PrivateKeyFactory.CreateKey(serializedPrivateBytes);

        }


        public ECPublicKeyParameters GetPublicKeyParameters(byte[] ephemeralPublicKeyBytes)
        {
            return (ECPublicKeyParameters)PublicKeyFactory.CreateKey(ephemeralPublicKeyBytes);
        }


        private byte[] GenerateSharedSecret(ECPrivateKeyParameters privateKey, ECPublicKeyParameters publicKeys)
        {
            ECPrivateKeyParameters keyParams = privateKey;
            IBasicAgreement agree = AgreementUtilities.GetBasicAgreement("ECDH");
            agree.Init(keyParams);
            BigInteger sharedSecret = agree.CalculateAgreement(publicKeys);
            return sharedSecret.ToByteArrayUnsigned();
        }

        protected byte[] RestoreSymmertricKey(byte[] sharedSecretBytes)
        {
            //var identity = GetPublicKeyHash();
            byte[] merchantIdentifier = GetHashSha256Bytes("merchant.applepaytest.azurewebsites.net");//applePayRequest.MerchantIdentifier);

            ConcatenationKdfGenerator generator = new ConcatenationKdfGenerator(new Sha256Digest());
            //byte[] COUNTER = { 0x00, 0x00, 0x00, 0x01 };
            byte[] algorithmIdBytes = Encoding.UTF8.GetBytes((char)0x0d + "id-aes256-GCM");
            byte[] partyUInfoBytes = Encoding.UTF8.GetBytes("Apple");
            byte[] partyVInfoBytes = merchantIdentifier;
            byte[] otherInfoBytes = Combine(Combine(algorithmIdBytes, partyUInfoBytes), partyVInfoBytes);

            generator.Init(new KdfParameters(sharedSecretBytes, otherInfoBytes));
            byte[] encryptionKeyBytes = new byte[32];
            generator.GenerateBytes(encryptionKeyBytes, 0, encryptionKeyBytes.Length);
            return encryptionKeyBytes;
        }

        private byte[] DoDecrypt(byte[] cipherData, byte[] encryptionKeyBytes)
        {
            byte[] output;
            try
            {
                KeyParameter keyparam = ParameterUtilities.CreateKeyParameter("AES", encryptionKeyBytes);
                ParametersWithIV parameters = new ParametersWithIV(keyparam, symmetricIv);
                IBufferedCipher cipher = GetCipher();
                cipher.Init(false, parameters);
                try
                {
                    output = cipher.DoFinal(cipherData);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Invalid Data");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("There was an error occured when decrypting message.");
            }

            return output;
        }

        public IBufferedCipher GetCipher()
        {
            return CipherUtilities.GetCipher("AES/GCM/NoPadding");
        }



        private static byte[] GetHashSha256Bytes(string text)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            byte[] hash = hashstring.ComputeHash(bytes);
            return hash;
        }

        protected static byte[] Combine(byte[] first, byte[] second)
        {
            byte[] ret = new byte[first.Length + second.Length];
            Buffer.BlockCopy(first, 0, ret, 0, first.Length);
            Buffer.BlockCopy(second, 0, ret, first.Length, second.Length);
            return ret;
        }
    }
}
