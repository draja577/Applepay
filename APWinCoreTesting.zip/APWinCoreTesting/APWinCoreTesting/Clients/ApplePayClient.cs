﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace APWinCoreTesting.Clients
{
    public class ApplePayClient
    {
        private readonly HttpClient _httpClient;

        public ApplePayClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<JObject> GetMerchantSessionAsync(string requestUri,MerchantSessionRequest request,X509Certificate2 certificate)
        {
            try
            {
                using (var httpClient = CreateHttpClient(certificate))
                {
                    var jsonPayload = JsonConvert.SerializeObject(request);

                    using (var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json"))
                    {
                        // POST the data to create a valid Apple Pay merchant session.
                        using (var response = await httpClient.PostAsync(requestUri, content))
                        {
                            response.EnsureSuccessStatusCode();
                            var merchantSessionJson = await response.Content.ReadAsStringAsync();
                            return JObject.Parse(merchantSessionJson);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private HttpClient CreateHttpClient(X509Certificate2 certificate)
        {
            var handler = new HttpClientHandler();
            handler.ClientCertificates.Add(certificate);
            handler.SslProtocols = SslProtocols.Tls12;
            return new HttpClient(handler);
        }
    }
}
