﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using APWinCoreTesting.Clients;
using APWinCoreTesting.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;

namespace APWinCoreTesting.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplePayClient _client;
        private readonly MerchantCertificate _certificate;
        private readonly PaymentCertificate _paymentcertificate;
        private readonly ApplePayOptions _options;
        private readonly IHostingEnvironment _env;
        private readonly ApplePayRequest _req;
        public HomeController(ApplePayClient client,MerchantCertificate certificate,IOptions<ApplePayOptions> options, PaymentCertificate paymentCertificate, IHostingEnvironment env, IOptions<ApplePayRequest> req)
        {
            _client = client;
            _certificate = certificate;
            _paymentcertificate = paymentCertificate;
            _options = options.Value;
            _req = req.Value;
            _env = env;
        }
        public IActionResult Index()
        {
            var webRoot = _env.WebRootPath;
            var file = Path.Combine(webRoot, @"Certs\MerchantIdentityCert.p12");
            _options.MerchantCertificateFileName = file;
            _options.MerchantCertificatePassword = "applemerchantcertsecret";
            //var paymentFilePath = Path.Combine(webRoot, @"Certs\tradfile.pem");
            var model = new HomeModel()
            {
                MerchantId = _certificate.GetMerchantIdentifier(),
                //PaymentKey = _paymentcertificate.Decrypt(paymentFilePath),
                StoreName = _options.StoreName,
            };

            return View(model);
        }
        
        #region test
        [HttpPost]
        [Produces("application/json")]
        [Route("applepay/validate2", Name = "MerchantValidation2")]
        public async Task<IActionResult> Validate2()
        {
            try
            {
                var request = new MerchantSessionRequest()
                {
                    MerchantIdentifier = _certificate.GetMerchantIdentifier(),
                    DomainName = "apwincoretesting.azurewebsites.net",
                    DisplayName = ""
                };

                JObject merchantSession = await _client.GetMerchantSessionAsync(
                    "https://apple-pay-gateway-cert.apple.com/paymentservices/startSession", request,
                    _certificate.GetCertificate());

                return Json(merchantSession);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
        #endregion

        [HttpPost]
        [Produces("application/json")]
        [Route("applepay/validate", Name = "MerchantValidation")]
        public async Task<IActionResult> Validate([FromBody] ValidateMerchantSessionModel model)
        {
            if (!ModelState.IsValid ||
                string.IsNullOrWhiteSpace(model?.ValidationUrl) ||
                !Uri.TryCreate(model.ValidationUrl, UriKind.Absolute, out Uri requestUri))
            {
                return BadRequest();
            }

            // Create the JSON payload to POST to the Apple Pay merchant validation URL.
            var request = new MerchantSessionRequest()
            {
                MerchantIdentifier = _certificate.GetMerchantIdentifier(),
                DomainName = Request.GetTypedHeaders().Host.Value,
                DisplayName = _options.StoreName ?? ""
            };

            JObject merchantSession = await _client.GetMerchantSessionAsync(model.ValidationUrl, request, _certificate.GetCertificate());

            // Return the merchant session as-is to the JavaScript as JSON.
            return Json(merchantSession);
        }

        //[HttpPost]
        //[Produces("application/json")]
        //[Route("applepay/GetPaymentData", Name = "PaymentTokenData")]
        //public string GetPaymentData([FromBody] ApplePayRequest model)
        //{

        //    return _paymentcertificate.Decrypt(model);
        //}

        [HttpPost]
        [Produces("application/json")]
        [Route("applepay/GetPaymentData", Name = "PaymentTokenData")]
        public JsonResult GetPaymentData([FromBody] ApplePayRequest model)
        {

            var decrypt= _paymentcertificate.Decrypt(model);
            return Json(decrypt);
        }
        public IActionResult Error() => View();
    }
}
