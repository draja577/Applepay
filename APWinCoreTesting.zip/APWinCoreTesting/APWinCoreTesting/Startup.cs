﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading.Tasks;
using APWinCoreTesting.Clients;
using APWinCoreTesting.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace APWinCoreTesting
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        //public void ConfigureServices(IServiceCollection services)
        //{
        //    services.Configure<CookiePolicyOptions>(options =>
        //    {
        //        // This lambda determines whether user consent for non-essential cookies is needed for a given request.
        //        options.CheckConsentNeeded = context => true;
        //        options.MinimumSameSitePolicy = SameSiteMode.None;
        //    });


        //    services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        //}
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOptions();
            services.Configure<ApplePayOptions>(Configuration.GetSection("ApplePay"));

            services.AddAntiforgery(options =>
            {
                options.Cookie.Name = "antiforgerytoken";
                options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                options.HeaderName = "x-antiforgery-token";
            });

            services.AddMvc(
                options =>
                {
                    // Apple Pay JS requires pages to be served over HTTPS
                    //if (Environment.IsProduction())
                    //{
                    //    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
                    //    options.Filters.Add(new RequireHttpsAttribute());
                    //}
                })
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            // Register class for managing the application's use of the Apple Pay merchant certificate
            services.AddSingleton<MerchantCertificate>();
            services.AddSingleton<PaymentCertificate>();

            // Create a typed HTTP client with the merchant certificate for two-way TLS authentication over HTTPS.
            services
                .AddHttpClient<ApplePayClient>("ApplePay")
                .ConfigurePrimaryHttpMessageHandler(
                    (serviceProvider) =>
                    {
                        var merchantCertificate = serviceProvider.GetRequiredService<MerchantCertificate>();
                        //var certificate = merchantCertificate.GetCertificate();

                        var handler = new HttpClientHandler();
                        //handler.ClientCertificates.Add(certificate);

                        // Apple Pay JS requires the use of at least TLS 1.2 to generate a merchange session:
                        // https://developer.apple.com/documentation/applepayjs/setting_up_server_requirements
                        // If you run an older operating system that does not negotiate this by default, uncomment the line below.
                        // handler.SslProtocols = SslProtocols.Tls12;

                        return handler;
                    });
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
